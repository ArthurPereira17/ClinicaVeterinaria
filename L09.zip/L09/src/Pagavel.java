public interface Pagavel {

    double getValorTotal();
    String getDescricaoPagamentos();
}
