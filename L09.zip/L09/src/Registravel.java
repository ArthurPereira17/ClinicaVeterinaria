public interface Registravel {
    public void registrarNoSistema();
}
